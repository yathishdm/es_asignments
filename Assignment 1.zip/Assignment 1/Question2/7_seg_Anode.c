#include<lpc13xx.h>
void delay(unsigned int c)
{unsigned int a;
for(a=1;a<=200000;a++);}

int main()
{

LPC_GPIO1->DIR=0x00000FF0;

	LPC_GPIO0->DIR &= ~((1<<9));
while(1){
if(!(LPC_GPIO0->DATA & (1<<9))){
LPC_GPIO1->DATA =0xC00;
delay(20000);
LPC_GPIO1->DATA =0xF90;
delay(20000);	
LPC_GPIO1->DATA =0xA40;
delay(20000);
LPC_GPIO1->DATA =0xB00;
delay(20000);
LPC_GPIO1->DATA =0x990;	
delay(20000);
LPC_GPIO1->DATA =0x920;
delay(20000);
LPC_GPIO1->DATA =0x820;
delay(20000);
LPC_GPIO1->DATA =0xF80;
delay(20000);
LPC_GPIO1->DATA =0x800;
delay(20000);
LPC_GPIO1->DATA =0x900;
delay(20000);
}
}
}
